import requests
import csv
import pandas as pd

#array = [1000,2000,3000,4000,5000,6000,7000,8000,9000,10000,11000,12000,13000,14000,15000,16000,17000,18000,19000,20000]
#let array = 

array = range(1000,50000,1000)

for i in array:
	print(i)
	if(i == 1000):
		res = requests.get("https://jira.atlassian.com/sr/jira.issueviews:searchrequest-csv-all-fields/temp/SearchRequest.csv?jqlQuery=&delimiter=,pager/start=" + str(i) + "&tempMax=1000")

		decoded_content = res.content.decode('utf-8')
		    
		cr = csv.reader(decoded_content.splitlines(), delimiter=',')
		my_list = list(cr)
		temp = my_list
	else:	

		res = requests.get("https://jira.atlassian.com/sr/jira.issueviews:searchrequest-csv-all-fields/temp/SearchRequest.csv?jqlQuery=&delimiter=,pager/start=" + str(i) + "&tempMax=1000")

		decoded_content = res.content.decode('utf-8')
		    
		cr = csv.reader(decoded_content.splitlines(), delimiter=',')
		my_list = list(cr)
		my_list.pop(0)
		for j in my_list:
			temp.append(j)


with open('GFG_FINAL.csv', 'w') as f:
	# using csv.writer method from CSV package
	write = csv.writer(f)
	write.writerows(temp)    