from jiraone import LOGIN, issue_export
import json

file = "config.json"
config = json.load(open(file))
LOGIN(**config)

jql = "project in (AB, BC, IT, IP) order by created DESC"
issue_export(jql=jql)

# If you want to rename the export filename, 
# previous expression
export_file = "example_export.csv"
# Then, you can do
issue_export(jql=jql, final_file=export_file)